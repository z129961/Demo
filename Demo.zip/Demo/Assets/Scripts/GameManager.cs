using Spine.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    static GameManager instance;
    public static GameManager Instance
    {
        get => instance;
    }

    [SerializeField]
    public GameObject g_bg,player,sofaPoint;
    [SerializeField]
    public Sprite[] foldClothesSprites;//�۵����·�ͼƬ��
    [SerializeField]
    public Sprite[] launchClothesSprites;//չ�����·�ͼƬ��

    List<Transform> l_objects = new List<Transform>();

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        Init();
    }

    private void Init()
    {
        TraverseChildren(g_bg.transform);//��ȡ��������������
        GameObject[] objects = GetAllResourcePaths();//��ȡ��Resources/Prefabs������Ԥ����
        foreach (var obj in l_objects)
        {
            foreach (var item in objects)
            {
                if (obj.tag == item.tag)
                {
                    Instantiate(item, obj.transform);
                }
            }
        }
    }

    /// <summary>
    /// ����bg���������������Transform
    /// </summary>
    /// <param name="parent"></param>
    private void TraverseChildren(Transform parent)
    {
        for (int i = 0; i < parent.childCount; i++)
        {
            Transform child = parent.GetChild(i);

            l_objects.Add(child.transform);
        }
    }

    /// <summary>
    /// ��ȡ��Դ·��
    /// </summary>
    /// <returns></returns>
    private GameObject[] GetAllResourcePaths()
    {
        
        GameObject[] allResourcePaths = Resources.LoadAll<GameObject>("Prefabs");
        return allResourcePaths;
    }
}
