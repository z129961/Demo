using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Coffee : OnDragBase
{
    float xMax = 5.4f;//��Ϊ��Сxֵ����Ϊ���xֵ
    float xMin = -4.5f;//��Ϊ��Сxֵ����Ϊ���xֵ
    float yMin = -6.25f;//��Сyֵ
    float yMax = 3.74f;//���yֵ

    UnityAction<GameObject,Transform> dEating;//�Զ���
    GameObject player, child;
    SpriteRenderer renderer;

    Transform parent;
    Transform onBeforeParent;
    private void Start()
    {
        mainCamera = Camera.main;
        parent = gameObject.transform.parent.parent;
        onBeforeParent = transform.parent;
        player = GameManager.Instance.player;
        dEating = player.GetComponent<PlayerOnDrag>().IEnumeratorCallPlayerEatingAnim;
        renderer = GetComponent<SpriteRenderer>();
        child = transform.GetChild(0).gameObject;
    }
    private void Update()
    {
        StartCoroutine(IfCoffeeChildIsFalse());
    }
    private void OnMouseDown()
    {
        OnDragStart();
    }
    private void OnMouseDrag()
    {
        OnDrag();
    }
    private void OnMouseUp()
    {
        OnDragEnd();
    }

    /// <summary>
    /// ��д��ʼ�϶��߼�
    /// </summary>
    protected override void OnDragStart()
    {
        transform.localScale = Vector3.one * 1.3f;
        transform.SetParent(parent);

        renderer.sortingOrder = 50;//��ʼ��קʱ��ͼ������Ϊ50
        child.GetComponent<SpriteRenderer>().sortingOrder = 51;

        base.OnDragStart();
    }

    protected override void OnDrag()
    {
        if (isDragging)
        {
            Vector3 targetPosition = GetMouseWorldPosition() + offset;

            // ����ɫλ���Ƿ񳬳���Χ
            targetPosition.x = Mathf.Clamp(targetPosition.x, xMin, xMax);
            targetPosition.y = Mathf.Clamp(targetPosition.y, yMin, yMax);

            transform.position = targetPosition;
        }
    }

    protected override void OnDragEnd()
    {
        #region = =
        //if (isDragging)
        //{
        //    // ��ȡ����ק�����λ��
        //    Vector2 dragObjectPosition = transform.position;

        //    // ��⸽��������
        //    Collider2D[] nearbyColliders = Physics2D.OverlapCircleAll(dragObjectPosition, 0.5f); // ���ü��뾶Ϊ1����λ����

        //    bool foundTarget = false; // ��־��������ʾ�Ƿ��ҵ���Ŀ������

        //    // ������⵽������
        //    foreach (Collider2D collider in nearbyColliders)
        //    {
        //        if (collider.name == gameObject.name)
        //        {
        //            continue;
        //        }
        //        // �����⵽��Ŀ������
        //        if (collider.CompareTag("Placement_Point"))
        //        {
        //            GameObject draggedToObject = collider.gameObject;
        //            if (draggedToObject.transform.childCount == 0 && draggedToObject.layer == LayerMask.NameToLayer("Placement_Point"))
        //            {
        //                // ������ק�����λ������ΪĿ�������λ��
        //                transform.position = collider.transform.position;
        //                transform.SetParent(collider.transform);//������ק�������ø��ڵ�
        //                foundTarget = true;
        //                break;
        //            }
        //            else if(!foundTarget)
        //            {
        //                Vector3 currentPosition = transform.position;
        //                // ��������Ƿ��ڷ�Χ��
        //                if (currentPosition.y > -5f)
        //                {
        //                    StartCoroutine(DropAnimation(transform, -5f, 1f));
        //                }
        //                break;
        //            }
        //        }
        //        else if (collider.CompareTag("Player"))
        //        {
        //            dEating(gameObject, onBeforeParent);
        //            break;
        //        }
        //        else
        //        {
        //            if (transform.position.y > -5f)
        //            {
        //                StartCoroutine(DropAnimation(transform, -5f, 1f));
        //            }
        //        }
        //    }
        //}
        #endregion
        GetObjectCoffeeDragEnd(gameObject, transform, -5f, "Placement_Point", "Player", dEating, onBeforeParent, renderer,child);
        
    }
    IEnumerator IfCoffeeChildIsFalse()
    {
        // ��ȡ������
        Transform child = gameObject.transform.GetChild(0);

        // �ж��������Ƿ���δ����״̬
        if (!child.gameObject.activeSelf)
        {
            // �ȴ�10��
            yield return new WaitForSeconds(10f);

            // ����������
            child.localScale = Vector3.one;
            child.gameObject.SetActive(true);
        }
    }


}
